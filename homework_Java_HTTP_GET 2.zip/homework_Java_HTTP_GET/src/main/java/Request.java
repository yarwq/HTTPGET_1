import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

import java.io.InputStream;
import java.net.Authenticator;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.net.*;

public class Request {
    private final String method;
    private final String path;
    private final Map<String, String> headers;
    private final InputStream body;
    private Map<String, String> queryParams = new HashMap<>();
    public Request(String method, String path, Map<String, String> headers, InputStream body) {
        this.method = method;
        this.path = path;
        this.headers = headers;
        this.body = body;
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public InputStream getBody() {
        return body;
    }
    private void parseQueryParams(String path) {
        String uri = "http://localhost" + path; // Добавление протокола и хоста для корректного парсинга
        List<NameValuePair> params = URLEncodedUtils.parse(URI.create(uri), StandardCharsets.UTF_8);
        for (NameValuePair param : params) {
            queryParams.put(param.getName(), param.getValue());
        }
    }
    private String parsePath(String path) {
        int queryStart = path.indexOf(path);
        return (queryStart >= 0) ? path.substring(0, queryStart) : path;
    }
}
