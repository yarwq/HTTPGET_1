import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        Server server = new Server();

        server.addHandler("GET", "/messages", (request, responseStream) -> {
            String response = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/plain\r\n" +
                    "Content-Length: 13\r\n" +
                    "Connection: close\r\n" +
                    "\r\n" +
                    "Hello, World!";
            responseStream.write(response.getBytes());
            responseStream.flush();
        });

        server.addHandler("POST", "/messages", (request, responseStream) -> {
            // Example POST handler
            String response = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/plain\r\n" +
                    "Content-Length: 7\r\n" +
                    "Connection: close\r\n" +
                    "\r\n" +
                    "Posted!";
            responseStream.write(response.getBytes());
            responseStream.flush();
        });

        try {
            server.listen(9999);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
