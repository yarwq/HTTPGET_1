import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import java.io.InputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Request {
    private String method;
    private String path;
    private Map<String, String> headers;
    private InputStream body;
    private Map<String, List<String>> parseBody = new HashMap<>();
    private Map<String, List<FileItem>> fileItems = new HashMap<>();

    public Request(String method, String path, Map<String, String> headers, InputStream body) {
        this.method = method;
        this.path = path.split("\\?")[0];
        this.headers = headers;
        this.body = body;
        if ("POST".equalsIgnoreCase(method)) {
            if (headers.get("Content-Type").equals("application/x-www-form-urlencoded")) {
                parseFormUrlEncodedBody();
            } else if (headers.get("Content-Type").startsWith("multipart/form-data")) {
                parseMultipartBody();
            }
        }
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public InputStream getBody() {
        return body;
    }

    private void parseFormUrlEncodedBody() {
        try {
            StringBuilder bodyString = new StringBuilder();
            int i;
            while ((i = body.read()) != -1) {
                bodyString.append((char) i);
            }
            String[] pairs = bodyString.toString().split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=");
                if (keyValue.length == 2) {
                    String key = URLDecoder.decode(keyValue[0], StandardCharsets.UTF_8.name());
                    String value = URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8.name());
                    parseBody.computeIfAbsent(key, k -> new ArrayList<>()).add(value);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void parseMultipartBody() {
        try {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            List<FileItem> items = upload.parseRequest(new org.apache.commons.fileupload.RequestContext() {
                @Override
                public String getCharacterEncoding() {
                    return StandardCharsets.UTF_8.name();
                }

                @Override
                public String getContentType() {
                    return headers.get("Content-Type");
                }

                @Override
                public int getContentLength() {
                    return headers.containsKey("Content-Length") ? Integer.parseInt(headers.get("Content-Length")) : -1;
                }

                @Override
                public InputStream getInputStream() {
                    return body;
                }
            });

            for (FileItem item : items) {
                if (item.isFormField()) {
                    parseBody.computeIfAbsent(item.getFieldName(), k -> new ArrayList<>()).add(item.getString());
                } else {
                    fileItems.computeIfAbsent(item.getFieldName(), k -> new ArrayList<>()).add(item);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getPostParam(String name) {
        return parseBody.get(name);
    }

    public Map<String, List<String>> getPostParams() {
        return parseBody;
    }

    public FileItem getPart(String name) {
        List<FileItem> items = fileItems.get(name);
        return (items != null && !items.isEmpty()) ? items.get(0) : null;
    }

    public Map<String, List<FileItem>> getParts() {
        return fileItems;
    }
}
