import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static final List<String> validPaths = List.of(
            "/index.html", "/spring.svg", "/spring.png", "/resources.html",
            "/styles.css", "/app.js", "/links.html", "/forms.html",
            "/classic.html", "/events.html", "/events.js");

    private final ExecutorService threadPool = Executors.newFixedThreadPool(64);
    private final ServerSocket serverSocket;

    public Server(int port) throws IOException {
        this.serverSocket = new ServerSocket(port);
    }

    public void start() {
        while (true) {
            try {
                Socket socket = serverSocket.accept();
                threadPool.submit(() -> handleClient(socket));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleClient(Socket socket) {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream())
        ) {
            String requestLine = in.readLine();
            if (requestLine == null || !requestLine.startsWith("GET")) {
                sendErrorResponse(out);
                return;
            }

            String[] parts = requestLine.split(" ");
            if (parts.length != 3) {
                sendErrorResponse(out);
                return;
            }

            String path = parts[1];
            if (!validPaths.contains(path)) {
                sendNotFoundResponse(out);
                return;
            }

            handleFileResponse(path, out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleFileResponse(String path, BufferedOutputStream out) throws IOException {
        Path filePath = Path.of(".", "public", path);
        String mimeType = Files.probeContentType(filePath);

        if (path.equals("/classic.html")) {
            String template = Files.readString(filePath);
            String content = template.replace("{time}", LocalDateTime.now().toString());
            sendResponse(out, "200 OK", mimeType, content.getBytes());
        } else {
            long length = Files.size(filePath);
            sendResponse(out, "200 OK", mimeType, length);
            Files.copy(filePath, out);
        }

        out.flush();
    }

    private void sendResponse(BufferedOutputStream out, String status, String contentType, long contentLength) throws IOException {
        out.write((
                "HTTP/1.1 " + status + "\r\n" +
                        "Content-Type: " + contentType + "\r\n" +
                        "Content-Length: " + contentLength + "\r\n" +
                        "Connection: close\r\n" +
                        "\r\n"
        ).getBytes());
    }

    private void sendResponse(BufferedOutputStream out, String status, String contentType, byte[] content) throws IOException {
        sendResponse(out, status, contentType, content.length);
        out.write(content);
    }

    private void sendErrorResponse(BufferedOutputStream out) throws IOException {
        out.write((
                "HTTP/1.1 400 Bad Request\r\n" +
                        "Content-Length: 0\r\n" +
                        "Connection: close\r\n" +
                        "\r\n"
        ).getBytes());
        out.flush();
    }

    private void sendNotFoundResponse(BufferedOutputStream out) throws IOException {
        out.write((
                "HTTP/1.1 404 Not Found\r\n" +
                        "Content-Length: 0\r\n" +
                        "Connection: close\r\n" +
                        "\r\n"
        ).getBytes());
        out.flush();
    }

    public static void main(String[] args) {
        try {
            Server server = new Server(9999);
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
